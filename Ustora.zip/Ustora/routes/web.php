<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\AdminController;
use App\Http\Controllers\Backend\ProductController;
use App\Http\Controllers\Frontend\FrontendController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/




Route::controller(FrontendController::class)->group(function(){
    Route::get('/', 'index')->name('home');

});



//admin logout

Route::get('/adminLogout',[AdminController::class,'destroy'])->name('admin.logout');

Route::get('/dashboard', function () {
    return view('backend.dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');




Route::controller(ProductController::class)->group(function(){
    
    Route::get('/products','index')->name('products.index');
    Route::post('/product/add','store')->name('product.add');
    Route::get('/product/manage','show')->name('product.manage');
    Route::get('/product/atoi/{id}','atoi')->name('product.atoi');
    Route::get('/product/itoa/{id}','itoa')->name('product.itoa');
    Route::get('/product/delete/{id}','delete')->name('product.delete');
    Route::get('/product/edit/{id}','edit')->name('product.edit');
    Route::post('/product/update/{id}','update')->name('product.update');
    Route::get('/product/singleProduct/{id}','singleProduct')->name('singleProduct');

});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
