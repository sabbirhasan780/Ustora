

<?php $__env->startSection('main-content'); ?>
                    <div class="container-fluid px-4">
                   
                        <h1 class="mt-4">Add Product</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="<?php echo e(Route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Manage Product</li>
                        </ol>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                            
                               <a href="<?php echo e(Route('products.index')); ?>" class="btn btn-primary btn-sm">Add Product</a>
                            </div>
                            <div class="card-body">
                                <table  class= " table table-striped" id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>#SL No.</th>
                                            <th>Product Name</th>
                                            <th>Product Image</th>
                                            <th>Current Price</th>
                                            <th> Previous Price</th>
                                            <th> Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>#SL No.</th>
                                            <th>Product Name</th>
                                            <th>Product Image</th>
                                            <th>Current Price</th>
                                            <th> Previous Price</th>
                                            <th> Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>

                                    <?php

                                    $name = 1;

                                    ?>

                        <?php if(count($product)>0): ?>

                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                                            <td><?php echo e($name++); ?></td>
                                            <td><?php echo e($productItem->product_name); ?></td>
                                            <td>
                                                     <img src="<?php echo e(asset('uploads/product/'.$productItem->product_image)); ?>" alt="" height="80px" width="80px">
                                            </td>
                                           
                                            <td><?php echo e($productItem->current_price); ?></td>
                                            <td><?php echo e($productItem->prev_price); ?></td>
                                            <td>

                                            <?php if($productItem->status == 1): ?>


                                            <a href="<?php echo e(Route('product.atoi',$productItem->id)); ?>" class=" btn-sm btn-success"> 
                                            <i class="fa-solid fa-user-check"></i></i></a>

                                                <?php else: ?>
                                                <a href="<?php echo e(Route('product.itoa',$productItem->id)); ?>" class=" btn-sm btn-danger"> <i class="fa-solid fa-user-xmark"></i>
                                                </i></a>

                                                


                                            <?php endif; ?>
                                            </td>
                                            
                                            <td>
                                                <a href="<?php echo e(Route('product.edit',$productItem->id)); ?>" class="btn btn-warning btn-sm"> 
                                                    <i class="fa-solid fa-pen-to-square"></i> </a>
                                                <a href="<?php echo e(Route('product.delete',$productItem->id)); ?>" class=" btn-danger btn-sm">
                                                    <i class="fa-solid fa-trash"></i> </a>
                                            </td>
                                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="btn btn-danger">Data Not Found</td>
                        </tr>

                        <?php endif; ?> 
                                      
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\php laravel course\htdocs\Laravel\Md. Sabbir Hasan_0400038661\resources\views/backend/product/manage.blade.php ENDPATH**/ ?>