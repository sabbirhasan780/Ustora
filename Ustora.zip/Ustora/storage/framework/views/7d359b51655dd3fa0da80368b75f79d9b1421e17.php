<?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.includes.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

       
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav"> 

            <?php echo $__env->make('backend.includes.sideber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
            <div id="layoutSidenav_content">
                <main>
         <?php echo $__env->yieldContent('main-content'); ?>
                </main>
 <?php echo $__env->make('backend.includes.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

 <?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\php laravel course\htdocs\Laravel\five-app\resources\views/backend/master.blade.php ENDPATH**/ ?>