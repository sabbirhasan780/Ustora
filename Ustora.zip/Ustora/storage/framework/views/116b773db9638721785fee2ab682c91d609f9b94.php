

<?php $__env->startSection('main-content'); ?>
                    <div class="container-fluid px-4">
                   
                        <h1 class="mt-4">Update Product</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="<?php echo e(Route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Update</li>
                        </ol>
                        <div class="row">
                        <div class="col-lg-6 offset-lg-3">
                            <form action="<?php echo e(Route('product.update',$product->id)); ?>" method="POST" enctype="multipart/form-data" class="shadow" p-4>

                            <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="p_name">Product Name</label>
                                     <input type="text" name="p_name" id="p_name" class="form-control" value="<?php echo e($product->product_name); ?>">      
                            </div>

                            <div class="form-group mb-3">
                                    <label for="p_image">Product Image</label>
                                     <input type="file" name="p_image" id="p_image" class="form-control" > 
                                     
                                     <img src="<?php echo e(asset('uploads/product/'.$product->product_image)); ?>" alt="" height="50px" width="50px" class="mt-3">
                            </div>


                            <div class="form-group mb-3">
                                    <label for="c_price">Current Price</label>
                                     <input type="text" name="c_price" id="c_price" class="form-control" value="<?php echo e($product->current_price); ?>">      
                            </div>
                            <div class="form-group mb-3">
                                    <label for="p_price">Previous Price</label>
                                     <input type="text" name="p_price" id="p_price" class="form-control" value="<?php echo e($product->prev_price); ?>" >      
                            </div>
                           
                            <div class="form-group mb-3">
                                    
                                     <input type="submit"  class="btn btn-primary w-100" value="Update Product">      
                            </div>
                            </form>
                        </div>
                        </div>
                 
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\php laravel course\htdocs\Laravel\five-app\resources\views/backend/product/edit.blade.php ENDPATH**/ ?>