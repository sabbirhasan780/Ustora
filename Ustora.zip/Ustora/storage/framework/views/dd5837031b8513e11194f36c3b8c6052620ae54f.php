

<?php $__env->startSection('main-content'); ?>
                    <div class="container-fluid px-4">
                   
                        <h1 class="mt-4">Add Product</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="<?php echo e(Route('dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Tables</li>
                        </ol>
                        <div class="row">
                        <div class="col-lg-6 offset-lg-3">
                            <form action="<?php echo e(Route('product.add')); ?>" method="POST" enctype="multipart/form-data" class="shadow" p-4>

                            <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="p_name">Product Name</label>
                                     <input type="text" name="p_name" id="p_name" class="form-control" placeholder="Enter Product Name">      
                            </div>
                            <div class="form-group mb-3">
                                    <label for="p_image">Product Image</label>
                                     <input type="file" name="p_image" id="p_image" class="form-control" >      
                            </div>
                            <div class="form-group mb-3">
                                    <label for="c_price">Current Price</label>
                                     <input type="text" name="c_price" id="c_price" class="form-control" placeholder="Enter Current Price">      
                            </div>
                            <div class="form-group mb-3">
                                    <label for="p_price">Previous Price</label>
                                     <input type="text" name="p_price" id="p_price" class="form-control" placeholder="Enter Previous Price">      
                            </div>
                           
                            <div class="form-group mb-3">
                                    
                                     <input type="submit"  class="btn btn-primary w-100" value="Add Product">      
                            </div>
                            </form>
                        </div>
                        </div>
                 
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\php laravel course\htdocs\Laravel\Md. Sabbir Hasan_0400038661\resources\views/backend/product/index.blade.php ENDPATH**/ ?>