<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\File;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('backend.product.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $product = new Product();
        $product->product_name  = $request->p_name;      
        $product->current_price  = $request->c_price;
        $product->prev_price  = $request->p_price;

      if($image =   $request->file('p_image')){
        $customeImageName= uniqid().'.'.$image->getClientOriginalExtension();

        $image->move("uploads/product/",$customeImageName);
        $product->product_image = $customeImageName;
        $product->save();
        return redirect()->route('product.manage');

      }
         
    }

    /**
     * Display the specified resource.
   
     */
    public function show()
    {
         $product = Product::all();
        return view('backend.product.manage', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::find($id);
        return view('backend.product.edit',compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $product = Product::find($id);
        $product->product_name  = $request->p_name;      
        $product->current_price = $request->c_price;
        $product->prev_price  = $request->p_price;

        $deleteOldImage = "uploads/product/".$product->product_image;

        if($newimage = $request->file('p_image')){
            if(file_exists($deleteOldImage)){
                File::delete($deleteOldImage);
            }
            $newImageName =uniqid().'.'.$newimage->getClientOriginalExtension();
            $newimage->move("uploads/product/", $newImageName);
        }
        else{
            $newImageName = $product->product_image;
        }

        $product->product_image = $newImageName;
        $product->update();
        return redirect()->route('product.manage');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $product = Product::find($id);

        $deleteoldimage = 'uploads/product/'.$product->product_image;

        if(file_exists($deleteoldimage)){

            File::delete($deleteoldimage);
        }

        $product->delete();
        return back ();


    }

    // Active to inactive

    public function atoi($id){

        $product = Product::find($id);
        $product->status = 0;
        $product->update();
        return back();


    }

      // Inactive to active

      public function itoa($id){

        $product = Product::find($id);
        $product->status = 1;
        $product->update();
        return back();


    }

    //singleProduct
    public function singleProduct($id){

        $product = Product::find($id);

        return view('frontend.single-product', compact('product'));
    }

}
